package v1;

public class Client
{
	//��̬����
	public static void main( String[] args )
	{
		Moveable tank = new Tank();
		
		Moveable tankTimeProxy = new TankTimeProxy( tank );
		Moveable logProxy = new TankLogProxy( tankTimeProxy );
		
		Moveable m = logProxy;
		m.move();
		
	}
}
