package v1;

public interface Moveable
{
	public void move();
}
