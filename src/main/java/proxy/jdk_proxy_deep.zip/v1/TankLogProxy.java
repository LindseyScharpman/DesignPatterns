package v1;

public class TankLogProxy implements Moveable
{
	Moveable target;

	public TankLogProxy( Moveable target )
	{
		this.target = target;
	}

	@Override
	public void move()
	{
		System.out.println( "LOG: begin!" );
		target.move();
		System.out.println( "LOG: end!" );
	}

}
