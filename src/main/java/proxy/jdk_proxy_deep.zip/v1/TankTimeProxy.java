package v1;

public class TankTimeProxy implements Moveable
{
	Moveable target;

	public TankTimeProxy( Moveable target )
	{
		this.target = target;
	}

	@Override
	public void move()
	{
		System.out.println( "Time: start at " + System.currentTimeMillis() );
		target.move();
		System.out.println( "Time: end at " + System.currentTimeMillis() );
	}

}
