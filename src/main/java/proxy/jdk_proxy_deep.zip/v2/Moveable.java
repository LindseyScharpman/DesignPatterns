package v2;

public interface Moveable
{
	public void move();
}
