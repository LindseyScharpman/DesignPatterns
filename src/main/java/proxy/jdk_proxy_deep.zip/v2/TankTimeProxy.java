package v2;

public class TankTimeProxy implements Moveable
{
	Moveable proxy;
	
	public TankTimeProxy( Moveable proxy )
	{
		this.proxy = proxy;
	}
	
	@Override
	public void move()
	{
		System.out.println("Time: start at " + System.currentTimeMillis());
		proxy.move();
		System.out.println("Time: end at " + System.currentTimeMillis());
	}

}
