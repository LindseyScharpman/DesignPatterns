package v3;

public class Client
{
	public static void main( String[] args )
	{
		Moveable tank = new Tank();

		Moveable m = (Moveable)Proxy.newProxyInstance();
		m.move();
		
	}
}
