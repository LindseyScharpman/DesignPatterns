package v3;

import java.util.Random;

public class Tank implements Moveable
{
	@Override
	public void move()
	{
		System.out.println("tank is moving...");
		try
		{
			Thread.sleep( new Random().nextInt( 2000 ) );
		}
		catch( InterruptedException e )
		{
			e.printStackTrace();
		}
	}

}
