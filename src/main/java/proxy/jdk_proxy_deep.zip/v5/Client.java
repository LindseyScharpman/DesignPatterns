package v5;

public class Client
{
	public static void main( String[] args ) throws Exception
	{
		Moveable tank = new Tank();

		Moveable m = (Moveable)Proxy.newProxyInstance(Moveable.class);
		System.out.println("before");
		m.move();
		
	}
}
