package v5;

public interface Moveable
{
	public void move();
}
