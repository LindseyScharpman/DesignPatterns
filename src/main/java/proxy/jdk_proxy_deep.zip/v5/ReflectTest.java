package v5;

import java.lang.reflect.Method;

public class ReflectTest
{
	public static void main( String[] args )
	{
		Method[] methods = v5.Moveable.class.getMethods();
		for(Method m : methods)
			System.out.println(m);
	}
}
