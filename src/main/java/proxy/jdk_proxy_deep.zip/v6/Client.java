package v6;

public class Client
{
	public static void main( String[] args ) throws Exception
	{
		Moveable tank = new Tank();
		InvocationHandler h = new TimeHandler(tank);
		
		// ���ش�������
		Moveable m = (Moveable)Proxy.newProxyInstance(Moveable.class, h);
		
		m.move();
		//m.stop();
	}
}
