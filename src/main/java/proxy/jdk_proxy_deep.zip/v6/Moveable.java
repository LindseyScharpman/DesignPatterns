package v6;

public interface Moveable
{
	public void move();

	void stop();
}
