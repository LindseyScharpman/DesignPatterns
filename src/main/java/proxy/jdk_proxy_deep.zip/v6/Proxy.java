package v6;

import java.io.File;
import java.io.FileWriter;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;

import javax.tools.JavaCompiler;
import javax.tools.JavaFileObject;
import javax.tools.StandardJavaFileManager;
import javax.tools.ToolProvider;
import javax.tools.JavaCompiler.CompilationTask;

public class Proxy
{
	//�ѽӿڴ�����,�Ϳ��Բ���ʵ��������ӿڵĴ�������
	public static Object newProxyInstance(Class interf, InvocationHandler h) throws Exception
	{
		String rt = "\r\n";
		String methodStr = "";
		
		/*
		Method[] methods = interf.getMethods();
		for(Method m : methods)
		{
			methodStr += "public void " + m.getName() + "()" + rt +
					"	{"+ rt + 
					"		System.out.println(\"Time: start! at \" + System.currentTimeMillis());"+ rt + 
					"		proxy." + m.getName() + "();"+ rt + 
					"		System.out.println(\"Time: end! at \" + System.currentTimeMillis());"+ rt + 
					"}";
		}
		//System.out.println(methodStr);
		*/
		
		Method[] methods = interf.getMethods();
		for(Method m : methods)
		{
			methodStr += "public void " + m.getName() + "(){" + rt +
					"	try{" + rt +
					"   Method md = "+ interf.getName() + ".class.getMethod(\"" + m.getName() + "\");" + rt +
					"	h.invoke( this,md);"  + rt +
					"	}catch(Exception e){ e.printStackTrace();}" + rt +

					"}";
		}
		System.out.println(methodStr);
		
		String src = 
		"package v6;" + rt +
		"import java.lang.reflect.*;" + rt + 
		"public class TankTimeProxy implements " +  interf.getName() + "{" + rt + 
		"	public TankTimeProxy( InvocationHandler h )" + rt + 
		"	{ " + rt + 
		"		this.h = h;" + rt + 
		"	}" + rt + 
		"   v6.InvocationHandler h;" + rt + 	
			methodStr + rt +
		"}";
		
		//1:����src�������ļ�
		String fileName = System.getProperty( "user.dir") +  "/tmp/v6/TankTimeProxy.java" ;
		//System.out.println(fileName); //G:\study\Java\JavaSE\DesignPattern\Proxy\Tank3
		File f = new File(fileName);
		FileWriter fw = new FileWriter( f );
		fw.write( src );
		fw.flush();
		fw.close();
		
		//2:�����ļ����б���
		//ע�ⲻҪ�ڹ�����������JREҪ����ΪJDK����,��Ϊ����������JDKĿ¼�²���
		JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
		//System.out.println(compiler.getClass().getName());
		StandardJavaFileManager fileMgr = compiler.getStandardFileManager( null, null, null );
		Iterable<? extends JavaFileObject> units = fileMgr.getJavaFileObjects( fileName );
		CompilationTask task = compiler.getTask( null, fileMgr, null, null, null, units );
		task.call();
		fileMgr.close();
		
		//3:���ص��ڴ�
		//��ClassLoader���뱣֤class�ļ���classPath·������
		URL[] urls = new URL[]{
				new URL("file:/" + System.getProperty( "user.dir") + "/tmp/"),
			};
		URLClassLoader ul = new URLClassLoader( urls );
		Class proxy = ul.loadClass( "v6.TankTimeProxy" );
		//System.out.println(c.getName());
		//���ﲻ����c.newInstance()��ΪnewInstance������޲εĹ�����
		Constructor constructor = proxy.getConstructor( InvocationHandler.class );
		
		//4:���ɴ�������
		Object o = constructor.newInstance( h );
		
		return o;
	}
}
