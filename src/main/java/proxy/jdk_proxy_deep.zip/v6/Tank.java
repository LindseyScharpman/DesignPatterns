package v6;

import java.util.Random;

public class Tank implements Moveable
{
	@Override
	public void move()
	{
		System.out.println("tank is moving...");
		try
		{
			Thread.sleep( new Random().nextInt( 2000 ) );
		}
		catch( InterruptedException e )
		{
			e.printStackTrace();
		}
	}

	@Override
	public void stop()
	{
		System.out.println("tank is stoping...");
		try
		{
			Thread.sleep( new Random().nextInt( 2000 ) );
		}
		catch( InterruptedException e )
		{
			e.printStackTrace();
		}
	}
}
