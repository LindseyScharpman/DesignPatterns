package v6;

import java.lang.reflect.Method;

public class TimeHandler implements InvocationHandler
{

	Object target;
	public TimeHandler(Object target)
	{
		this.target = target;
	}
	@Override
	public void invoke( Object o, Method m )
	{
		
		System.out.println( "Time: start #P# at " + System.currentTimeMillis() );
		
		try{
			// ���ñ���������target��m����
			m.invoke( target, new Object[]{/* ���� */} );
		}
		catch( Exception e ){ e.printStackTrace(); }
		
		System.out.println( "Time: end #P# at " + System.currentTimeMillis() );
	}
}
